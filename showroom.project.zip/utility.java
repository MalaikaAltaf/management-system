interface utility {
    public void get_details();
    public void set_details();
}





